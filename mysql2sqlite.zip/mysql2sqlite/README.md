Intro
------------
This CLI-php script reads the current datas from mySQL-database and produces datas for mobileApp.
This script create two files:

* SQLite file which is an extract of original database on server
* a tree.json, which contains all categories

Usage
-----
* Credentials for accessing DB
* folder in which both files are creating
